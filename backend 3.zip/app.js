const express = require("express")
const { default: mongoose } = require("mongoose")

const app = express()



module.exports = app