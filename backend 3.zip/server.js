const mongoose = require("mongoose")
const app = require("./app")

try {
    mongoose
        .connect('mongodb+srv://abdullahghaus0440:Power2Abdullah@ecommercelearning.3l0e6hu.mongodb.net/?retryWrites=true&w=majority&appName=EcommerceLearning')
        .then(inst => console.log("Mongoose Connected"))
} catch (err) {
    console.log(err)
}

app.listen(6000, () => {
    console.log("Server Connected")
})